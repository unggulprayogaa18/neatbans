/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SESSION;

/**
 *
 * @author PC
 */
public class Sessiontglterima {
     private static String tglterima;

    public static void setSessiontglterima(String tglterima) {
        Sessiontglterima.tglterima = tglterima;
    }
    
    
    
    
    
    
    public static String getSessiontglterima() {
        return tglterima;
    }
}
