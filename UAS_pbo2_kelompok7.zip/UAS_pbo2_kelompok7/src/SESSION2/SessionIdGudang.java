/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SESSION2;

/**
 *
 * @author PC
 */
public class SessionIdGudang {
     private static String Sidgudang;

    public static void setSessionIdGudang(String Sidgudang) {
        SessionIdGudang.Sidgudang = Sidgudang;
    }
    
    
    
    
    
    
    public static String getSessionIdGudang() {
        return Sidgudang;
    }
}
