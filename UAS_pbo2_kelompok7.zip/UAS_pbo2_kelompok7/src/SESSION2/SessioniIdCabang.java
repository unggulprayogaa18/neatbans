/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package SESSION2;

/**
 *
 * @author PC
 */
public class SessioniIdCabang {
        private static String kodeCabang;

    public static void setSessioniIdCabang(String kodeCabang) {
        SessioniIdCabang.kodeCabang = kodeCabang;
    }
    
    
    
    
    
    
    public static String getSessioniIdCabang() {
        return kodeCabang;
    }
}
